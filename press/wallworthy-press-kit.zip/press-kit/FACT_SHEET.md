# Wallworthy: fact sheet

**Wallworthy: Kids Art Gallery** is an iPhone app for keeping children's artwork. You scan the art pile, frame it, and keep it with your child's voice telling the story.

- **App Store:** https://apps.apple.com/app/id6829036669
- **Website:** https://benwortonh787.github.io/wallworthy/
- **Made by:** Ben, an independent developer and parent
- **Platform:** iPhone, iOS 18 or later
- **Price:** Free. Wallworthy Plus is a one-time $9.99 in-app purchase. No subscription.
- **Privacy:** no accounts, no ads, no analytics, nothing collected. Art stays on the phone and in the family's own iCloud.
- **Contact:** wallworthysupport@gmail.com

## What it does

**Free**
- **Scan the whole backpack at once.** Scan a stack of pages; each drawing is found, straightened and cleaned, then you tap which child made it.
- **A gallery for each child.** Every piece is framed, with a museum-style label: title, artist, age and date, grouped by school year.
- **Their voice.** The child records what the drawing is. The recording stays with the art.
- **Shared family gallery (new in 1.1).** Invite a partner or grandparents. Everyone sees the same children, drawings and voice notes, and anyone can add more. Free for everyone; it uses Apple's iCloud sharing, with no Wallworthy server.
- **Send to family.** Send a framed drawing as a picture, or as a short video with the child's voice.
- **Kid mode, iCloud backup, export everything.**

**Wallworthy Plus ($9.99 once)**
- **Bring to life:** the drawing wiggles, bounces, dances or floats on a backdrop, and can be saved as a video.
- **Art Shows:** a slideshow video of a school year.
- **Year in Art picture book:** an 8 × 8 inch PDF to print at home or at any photo-book service.
- Four extra frames and a home-screen widget.

## Media in this kit

| Folder | What |
|---|---|
| `logo/` | App icon (1024 px) and wordmark |
| `screenshots/iphone-*.png` | App Store screenshots (portrait) |
| `screenshots/wide-*.png` | Landscape images (1270 × 760) |
| `video/` | 42-second promo, vertical (1080 × 1920) and landscape (1920 × 1080) |

The children and artwork shown are sample content made for the app, not real children.
